package ParallelProject.FilmManagementSystemTest;


import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import ParallelProject.FilmManagementSystem.Actor;
import ParallelProject.FilmManagementSystem.Album;
import ParallelProject.FilmManagementSystem.DAO.ActorRepoDAO;
import ParallelProject.FilmManagementSystem.DAOImplementation.ActorRepoDAOImplementation;




public class testExamples {
@Mock private ActorRepoDAO actorDao;
	
	ActorRepoDAOImplementation service;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		service = new ActorRepoDAOImplementation(actorDao); 
	}
	
	@Test(expected=java.lang.NullPointerException.class)
	public void actorObjectNull(){
		
		service.addActor(null);
	}

	@Test
	public void actorONewValueAdd(){
		Actor a = new Actor();
		a.setAlbum(new Album());
		a.setFilm(new ArrayList<Film>());
		a.setFirstName("Salman");
		a.setLastName("Khan");
		a.setGender("male");
		Mockito.when(actorDao.save(a)).thenReturn(true);
		assertEquals("success",service.addActor(a));
	}
	
	@Test
	public void actorValueAlreadyPresent(){
		Actor a = new Actor();
		a.setAlbum(new Album());
		a.setFilm(new ArrayList());
		a.setFirstName("Salman");
		a.setLastName("Khan");
		a.setGender("male");
		Mockito.when(actorDao.save(a)).thenReturn(false);
		assertEquals("already present",service.addActor(a));
	}
	@Test(expected=java.lang.NullPointerException.class)
	public void actorNewValueNotValid(){
		
		Actor a = new Actor();
		a.setAlbum(new Album());
		a.setFilm(null);
		a.setFirstName("Salman");
		a.setLastName("Khan");
		a.setGender("male");
		
		service.addActor(a);	
	}
	
	@Test(expected=java.lang.Exception.class)
	public void addFilmSystemError(){
		Actor actor = new Actor();
		Mockito.when(actorDao.save(actor)).thenThrow(new SQLException());
		service.addActor(actor);
	}
	
	@Test(expected=java.lang.NullPointerException.class)
	public void modifyActorInputIsNull(){
		
		service.modifyActor(null);
	}
	
	@Test
	public void modifyActorInputIsNotPresent(){
		
		Actor actor = new Actor();
		actor.setId(1);
		Mockito.when(actorDao.modifyActor(actor)).thenReturn(false);
		assertEquals("unsuccess", service.modifyActor(actor));
	}

	@Test
	public void modifyActorInputValidAndModifyIt(){
		Actor actor = new Actor();
		Mockito.when(actorDao.modifyActor(actor)).thenReturn(true);
		assertEquals("success",service.modifyActor(actor));
	}
	
	@Test(expected=java.lang.Exception.class)
	public void modifyFilmSystemError(){
		Actor actor = new Actor();
		Mockito.when(actorDao.modifyActor(actor)).thenThrow(new SQLException());
		assertEquals("error",service.modifyActor(actor));
	}
	
	
	@Test(expected=java.lang.NullPointerException.class)
	public void searchByGenderInputNull() {
		service.searchByGender(null);
	}

	@Test
	public void searchByGenderValidInput(){
		List<Actor> l = new ArrayList<Actor>();
		l.add(new Actor());
		Mockito.when(actorDao.searchByGender("male")).thenReturn(l);
		assertFalse(service.searchByGender("male").isEmpty());
	
	}
	
	@Test(expected=java.lang.Exception.class)
	public void searchByGenderSystemError(){
		Actor actor = new Actor();
		Mockito.when(actorDao.searchByGender("male")).thenThrow(new SQLException());
		service.searchByGender("male");
	}
	
	@Test(expected=java.lang.NullPointerException.class)
	public void deleteActorInputIsnull(){
		service.deleteActor(null);
	}
	
	@Test
	public void deleteFilmInputNotPresent(){
		Mockito.when(actorDao.deleteActor("abc")).thenReturn(false);
		assertEquals("input not present", service.deleteActor("abc"));
	}
	@Test
	public void deleteFilmInputPresentAndDeleted(){
		Mockito.when(actorDao.deleteActor("Sultan")).thenReturn(true);
		assertEquals("deleted", service.deleteActor("Sultan"));
	}
	
	@Test(expected=java.lang.Exception.class)
	public void deleteActorSystemError(){
		Mockito.when(actorDao.deleteActor("Sultan")).thenThrow(new SQLException());
		service.deleteActor("Sultan");
	}
	
	@Test(expected=java.lang.NullPointerException.class)
	public void searchNyNameInputNull(){
		
		service.searchByName(null,"Khan");
	}
	
	@Test
	public void searchByNameValidInput(){
		List<Actor> l = new ArrayList<Actor>();
		l.add(new Actor());
		Mockito.when(actorDao.searchByName("Sharukh","Khan")).thenReturn(l);
		assertFalse(service.searchByName("Sharukh","Khan").isEmpty());
	
	}
	
	@Test
	public void searchByNameIfInputNotPresent(){

		Mockito.when(actorDao.searchByName("Amir","Khan")).thenReturn(null);
		assertEquals(null,service.searchByName("Amir","Khan"));
	
	}
	@Test(expected=java.lang.Exception.class)
	public void searchByNameSystemError(){
		Actor actor = new Actor();
		Mockito.when(actorDao.searchByName("Sharukh","Khan")).thenThrow(new SQLException());
		service.searchByName("Sharukh","Khan");
	}

}
