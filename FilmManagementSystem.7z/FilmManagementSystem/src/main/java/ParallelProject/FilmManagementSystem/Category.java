package ParallelProject.FilmManagementSystem;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
public class Category {
	@Id @GeneratedValue(strategy=GenerationType.TABLE) 
	private int id;
	private String categoryName;
	@Column(name = "createDate")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createDate;
	@Column(name = "deleteDate")
	@Temporal(TemporalType.DATE)
	private Date deleteDate;
	public Category() {
		// TODO Auto-generated constructor stub
	}
	public Category(String categoryName, Date createDate, Date deleteDate) {
		super();		
		this.categoryName = categoryName;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
		System.out.println(id+ "\t"+categoryName+"\t"+createDate.toString()+"\t"+deleteDate.toString());
	}	
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	@Override
	public String toString() {
		return "Category [id=" + id + ", categoryName=" + categoryName + ", createDate=" + createDate + ", deleteDate="
				+ deleteDate + "]";
	}
	
}
