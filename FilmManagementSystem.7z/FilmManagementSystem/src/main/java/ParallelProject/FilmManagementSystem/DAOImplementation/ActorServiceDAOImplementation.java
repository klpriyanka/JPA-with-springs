package ParallelProject.FilmManagementSystem.DAOImplementation;

import java.util.Date;
import java.util.List;

import ParallelProject.FilmManagementSystem.Actor;
import ParallelProject.FilmManagementSystem.Film;
import ParallelProject.FilmManagementSystem.DAO.ActorServiceDAO;

public class ActorServiceDAOImplementation implements ActorServiceDAO  {
		
	ActorRepoDAOImplementation actorRepo= new ActorRepoDAOImplementation();
	
	public String createActor(String firstName, String lastName, String gender, String albumName, List<Film> films) {
		if(firstName != null && lastName!= null){
			Actor actor=new Actor();
			actor.setFirstName(firstName);
			actor.setLastName(lastName);			
			actor.setAlbum(actorRepo.searchAlbum(albumName));
			actor.setCreateDate(new Date());
			actor.setGender(gender);			
			actor.setFilm(actorRepo.searFilmByName(films));
			System.out.println(actor);
			boolean result=actorRepo.addActor(actor);
			if(result){
				return "inserted Actor";
			}
		}
		return null;
	}

	public Boolean modifyActor(Actor actor) {
		if(actor!=null){
			return actorRepo.modifyActor(actor);
		}
		return false;
	}

	public Boolean deleteActor(Actor actor) {
		if(actor!=null){
			return actorRepo.deleteActor(actor);
		}
		return false;
	}

	public List<Actor> searchActorByFirstName(String firstNmae) {
		if(firstNmae != null){
			return (List<Actor>) actorRepo.searchActorByFirstName(firstNmae);
		}	
		return null;
	}

	public List<Actor> searchActorByFilm(String film) {
		if(film != null){
			return (List<Actor>) actorRepo.searchActorByFilm(film);
		}	
		return null;
	}

	public List<Actor> searchActorByLastName(String lastName) {
		if(lastName != null){
			return (List<Actor>) actorRepo.searchActorByLastName(lastName);
		}		
		return null;
	}
	public void closeEntitiy(){
		actorRepo.closeConnections();
	}

}
