package ParallelProject.FilmManagementSystem.DAOImplementation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import ParallelProject.FilmManagementSystem.Actor;
import ParallelProject.FilmManagementSystem.Album;
import ParallelProject.FilmManagementSystem.Category;
import ParallelProject.FilmManagementSystem.Film;
import ParallelProject.FilmManagementSystem.Image;
import ParallelProject.FilmManagementSystem.DAO.FilmRepoDAO;

public class FilmRepoDAOImplementation implements FilmRepoDAO {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");	
	EntityManager em = emf.createEntityManager();	
	
	ActorRepoDAOImplementation actorRepo=new ActorRepoDAOImplementation();	
	
	ArrayList<Actor> actors=(ArrayList<Actor>) actorRepo.fetchAllActors();
	ArrayList<Film>	films=(ArrayList<Film>) actorRepo.fetchAllFilms();
	ArrayList<Image> images=(ArrayList<Image>) actorRepo.fetchAllImages();
	ArrayList<Album> albums=(ArrayList<Album>) actorRepo.fetchAllAlbums();
	ArrayList<Category> categories=(ArrayList<Category>) fetchAllCategories();
	
	ArrayList<Film> filmList;
	
	public Boolean addFilm(Film film) {
		System.out.println(film.getTitle()+"********"+film.getDescription()+"**********");
		System.out.println("in repo");				
			if(!films.contains(film)){
				 em.getTransaction().begin();
				 em.persist(film);
				 em.getTransaction().commit();
			     return true;
			}		
		return false;
	}

	public Boolean modifyFilm(Film film) {
		for(int i=0;i<films.size();i++){
			if(films.get(i).getTitle().equals(film.getTitle())){
				 em.getTransaction().begin();
				 em.merge(film);
				 em.getTransaction().commit();
			     return true;
			}				
		}
		return false;
	}

	public Boolean deleteFilm(Film film) {
		for(int i=0;i<films.size();i++){
			if(films.get(i).getTitle().equals(film.getTitle())){
				 em.getTransaction().begin();
				 films.get(i).setDeleteDate(new Date());
				 em.merge(films.get(i));
				 em.getTransaction().commit();
			     return true;
			}				
		}
		return false;
	}

	public List<Film> searchFilmByFilmTitle(String filmName) {
		for(int i=0;i<films.size();i++){
			if(films.get(i).getTitle().equals(filmName))
				filmList.add(films.get(i));
		}
		return filmList;
	}

	public List<Film> searchFilmByActor(String actorName) {
		for(int i=0;i<films.size();i++){
			for(int j=0;j<films.get(i).getActors().size();j++){
				if(films.get(i).getActors().get(j).getFirstName().equals(actorName) || films.get(i).getActors().get(j).getLastName().equals(actorName) )
					filmList.add(films.get(i));
			}
		}
		return filmList;
	}

	public List<Film> searchFilmByReleaseDate(Date date) {
		for(int i=0;i<films.size();i++){
			if(films.get(i).getReleaseYear().equals(date))
				filmList.add(films.get(i));
		}
		return filmList;
	}

	public List<Film> searchFilmByRating(Byte rating) {
		for(int i=0;i<films.size();i++){
			if(films.get(i).getRating() == rating)
				filmList.add(films.get(i));
		}
		return filmList;
	}

	public List<Film> searchFilmByCategory(String category) {
		for(int i=0;i<films.size();i++){
			if(films.get(i).getCategory().equals(category))
				filmList.add(films.get(i));
		}
		return filmList;
	}

	public List<Film> searchFilmByLanguage(String language) {
		for(int i=0;i<films.size();i++){
			if(films.get(i).getLanguage().equals(language))
				filmList.add(films.get(i));
		}
		return filmList;
	}

	public List<Category> fetchAllCategories() {
		TypedQuery<Category> query=em.createQuery("select c from Category c ",Category.class);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Category> fetchCategoryByName(String categoryName) {
		 return (List<Category>) em.createQuery("select c from Category c where c.categoryName=:name").setParameter("name", categoryName).getResultList();
	}

	public Boolean addCategory(Category category) {
		if(!categories.contains(category)){
			 em.getTransaction().begin();
			 em.persist(category);
			 em.getTransaction().commit();
		     return true;
		}		
		return false;
	}

	public Boolean addImage(Image image) {
		if(!images.contains(image)){
			 em.getTransaction().begin();
			 em.persist(image);
			 em.getTransaction().commit();
		     return true;
		}		
		return false;
	}

	public Boolean addAlbum(Album album) {
		if(!albums.contains(album)){
			 em.getTransaction().begin();
			 em.persist(album);
			 em.getTransaction().commit();
		     return true;
		}		
		return false;
	}

}
