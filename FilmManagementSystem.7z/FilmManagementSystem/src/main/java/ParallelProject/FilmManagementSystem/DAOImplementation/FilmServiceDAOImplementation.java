package ParallelProject.FilmManagementSystem.DAOImplementation;

import java.util.Date;
import java.util.List;

import ParallelProject.FilmManagementSystem.Actor;
import ParallelProject.FilmManagementSystem.Album;
import ParallelProject.FilmManagementSystem.Category;
import ParallelProject.FilmManagementSystem.Film;
import ParallelProject.FilmManagementSystem.Image;
import ParallelProject.FilmManagementSystem.DAO.FilmServiceDAO;

public class FilmServiceDAOImplementation implements FilmServiceDAO{

	FilmRepoDAOImplementation filmRepo=new FilmRepoDAOImplementation();
	ActorRepoDAOImplementation actorRepo=new ActorRepoDAOImplementation();
	
	public String createFilm(String title, String description, Date releaseYear, String albumName, String language,
			String category, List<Actor> actors, Byte rating, short length) {
		if(title!=null){
			Film film=new Film();
			film.setTitle(title);
			film.setDescription(description);
			film.setLanguage(language);
			film.setLength(length);
			film.setRating(rating);
			film.setReleaseYear(releaseYear);
			film.setActors(actors);
			film.setAlbum(actorRepo.searchAlbum(albumName));
			film.setCreateDate(new Date());
			film.setCategory(searchCategoryName(category));
			System.out.println(film);
			boolean result=filmRepo.addFilm(film);
			if(result){
				return "inserted film";
			}
			
		}
		return null;
	}

	public Boolean modifyFilm(Film film) {
		if(film!=null){
			return filmRepo.modifyFilm(film);
		}
		return false;
	}

	public Boolean deleteFilm(Film film) {
		if(film!=null){
			return filmRepo.deleteFilm(film);
		}
		return false;
	}

	public List<Film> searchFilmByFilmTitle(String filmName) {
		if(filmName!=null){
			return (List<Film>) filmRepo.searchFilmByFilmTitle(filmName);
		}
		return null;
	}

	public List<Film> searchFilmByActor(String actorName) {
		if(actorName!=null){
			return (List<Film>) filmRepo.searchFilmByActor(actorName);
		}
		return null;
	}

	public List<Film> searchFilmByReleaseDate(Date date) {
		if(date!=null){
			return (List<Film>) filmRepo.searchFilmByReleaseDate(date);
		}
		return null;
	}

	public List<Film> searchFilmByRating(Byte rating) {
		if(rating!=null){
			return (List<Film>) filmRepo.searchFilmByRating(rating);
		}
		return null;
	}

	public List<Film> searchFilmByCategory(String category) {
		if(category!=null){
			return (List<Film>) filmRepo.searchFilmByCategory(category);
		}
		return null;
	}

	public List<Film> searchFilmByLanguage(String language) {
		if(language!=null){
			return (List<Film>) filmRepo.searchFilmByLanguage(language);
		}
		return null;
	}

	public String createCategory(String categoryName) {		
		if(categoryName != null ){
			Category category=new Category();
			category.setCategoryName(categoryName);
			category.setCreateDate(new Date());
			boolean result=filmRepo.addCategory(category);
			if(result){
				return "inserted Category";
			}
			
		}
		return null;
	}

	public String createImage(String imageURL) {
		if(imageURL != null ){
			Image image=new Image();
			image.setImageUrl(imageURL);
			image.setCreateDate(new Date());
			boolean result=filmRepo.addImage(image);
			if(result){
				return "inserted image";
			}
			
		}
		return null;
	}

	public String createAlbum(String albumName, List<Image> images) {
		if(albumName != null ){
			Album album=new Album();
			album.setAlbumName(albumName);
			for(int i=0;i<images.size();i++){
				Image image=new Image();
				image.setImageUrl(images.get(i).getImageUrl());
				image.setCreateDate(new Date());
				filmRepo.addImage(image);
			}
			boolean result=filmRepo.addAlbum(album);
			if(result){
				return "inserted image";
			}
			
		}
		return null;
	}

	public List<Category> searchCategoryName(String categoryName) {
		if(categoryName !=null){
			return filmRepo.fetchCategoryByName(categoryName);
		}
		return null;
	}

}
