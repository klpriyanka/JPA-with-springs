package ParallelProject.FilmManagementSystem.DAOImplementation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import ParallelProject.FilmManagementSystem.Actor;
import ParallelProject.FilmManagementSystem.Album;
import ParallelProject.FilmManagementSystem.Film;
import ParallelProject.FilmManagementSystem.Image;
import ParallelProject.FilmManagementSystem.DAO.ActorRepoDAO;

public class ActorRepoDAOImplementation implements ActorRepoDAO {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
	
	EntityManager em = emf.createEntityManager();	
	ArrayList<Actor> actorList=(ArrayList<Actor>) fetchAllActors();
	ArrayList<Film> filmList=(ArrayList<Film>) fetchAllFilms();
	ArrayList<Actor> actors;
	ArrayList<Film>	films;
		
	public boolean addActor(Actor actor) {
		System.out.println(actor.getFirstName()+"********"+actor.getLastName()+"**********"+actor.getGender());
		System.out.println("in repo");		
		ArrayList<Actor> actorList=(ArrayList<Actor>) fetchAllActors();			
			if(!actorList.contains(actor)){
				 em.getTransaction().begin();
				 em.persist(actor);
				 em.getTransaction().commit();
			     return true;
			}		
		return false;
	}

	public boolean modifyActor(Actor actor) {
				
		for(int i=0;i<actorList.size();i++){
			if(actorList.get(i).getFirstName().equals(actor.getFirstName()) && actorList.get(i).getLastName().equals(actor.getLastName())){
				 em.getTransaction().begin();
				 em.merge(actor);
				 em.getTransaction().commit();
			     return true;
			}				
		}
		return false;
	}

	public boolean deleteActor(Actor actor) {		
		
		for(int i=0;i<actorList.size();i++){
			if(actorList.get(i).getFirstName().equals(actor.getFirstName()) && actorList.get(i).getLastName().equals(actor.getLastName())){
				 em.getTransaction().begin();
				 actorList.get(i).setDeleteDate(new Date());
				 em.merge(actorList.get(i));
				 em.getTransaction().commit();
			     return true;
			}
				
		}
		return false;
	}

	public List<Actor> searchActorByFirstName(String firstNmae) {	
		for(int i=0;i<actorList.size();i++){
			if(actorList.get(i).getFirstName().equals(firstNmae))
				actors.add(actorList.get(i));
		}
		return actors;
	}

	public List<Actor> searchActorByFilm(String film) {
		
		for(int i=0;i<actorList.size();i++){
			if(actorList.get(i).getFilm().equals(film))
				actors.add(actorList.get(i));
		}
		return actors;
	}

	public List<Actor> searchActorByLastName(String lastName) {	
		for(int i=0;i<actorList.size();i++){
			if(actorList.get(i).getLastName().equals(lastName))
				actors.add(actorList.get(i));
		}
		return actors;
	}

	public List<Actor> fetchAllActors() {
		TypedQuery<Actor> query=em.createQuery("select a from Actor a",Actor.class);
		return query.getResultList();
	}

	public List<Album> fetchAllAlbums() {
		TypedQuery<Album> query=em.createQuery("select a from Album a",Album.class);
		return query.getResultList();
	}

	public List<Image> fetchAllImages() {
		TypedQuery<Image> query=em.createQuery("select i from  Image i",Image.class);
		return query.getResultList();
	}

	public List<Film> fetchAllFilms() {
		TypedQuery<Film> query=em.createQuery("select f from  Film f",Film.class);
		return query.getResultList();
	}

	public Album searchAlbum(String albumName) {
		 return (Album) em.createQuery("select a from Album a where a.albumName=:name").setParameter("name", albumName).getSingleResult(); 
		
	}
	
	public List<Film> searFilmByName(List<Film> filmsArray) {
		for(int i=0;i<filmsArray.size();i++){
			if(filmList.get(i).getTitle().equals(filmsArray.get(i).getTitle())){
				films.add(filmsArray.get(i));
			}
		}
		
		return films;
	}

	public void closeConnections(){
		em.close();
		emf.close();
	}

	

}
