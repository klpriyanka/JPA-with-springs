package ParallelProject.FilmManagementSystem;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
public class Film {
	@Id @GeneratedValue(strategy=GenerationType.TABLE) 
	private int id;
	private String title;
	private String description;
	private Date releaseYear;
	@OneToOne
	private Album album;
	private String language;
	@ManyToMany
	private List<Actor> actors;
	@ManyToMany
	private List<Category> category;
	private byte rating;
	private short length;
	@Temporal(TemporalType.DATE)
	private Date createDate;
	@Temporal(TemporalType.DATE)
	private Date deleteDate;
	public Film() {
		// TODO Auto-generated constructor stub
	}
	public Film(String title, String description, Date releaseYear, Album album, String language,
			List<Actor> actors, List<Category> category, byte rating, short length, Date createDate, Date deleteDate) {
		super();
		this.title = title;
		this.description = description;
		this.releaseYear = releaseYear;
		this.album = album;
		this.language = language;
		this.actors = actors;
		this.category = category;
		this.rating = rating;
		this.length = length;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public List<Actor> getActors() {
		return actors;
	}
	public void setActors(List<Actor> actors) {
		this.actors = actors;
	}
	public List<Category> getCategory() {
		return category;
	}
	public void setCategory(List<Category> category) {
		this.category = category;
	}
	public byte getRating() {
		return rating;
	}
	public void setRating(byte rating) {
		this.rating = rating;
	}
	public short getLength() {
		return length;
	}
	public void setLength(short length) {
		this.length = length;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	@Override
	public String toString() {
		return "Film [id=" + id + ", title=" + title + ", description=" + description + ", releaseYear=" + releaseYear
				+ ", album=" + album + ", language=" + language + ", actors=" + actors + ", category=" + category
				+ ", rating=" + rating + ", length=" + length + ", createDate=" + createDate + ", deleteDate="
				+ deleteDate + "]";
	}
	
}
