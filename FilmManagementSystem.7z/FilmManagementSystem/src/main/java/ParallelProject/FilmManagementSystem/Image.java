package ParallelProject.FilmManagementSystem;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
public class Image {
	@Id @GeneratedValue(strategy=GenerationType.TABLE) 
	private int id;
	private String imageUrl;
	@Temporal(TemporalType.DATE)
	private Date createDate;
	@Temporal(TemporalType.DATE)
	private Date deleteDate;
	
	public Image() {
		// TODO Auto-generated constructor stub
	}
	public Image(String imageUrl, Date createDate, Date deleteDate) {
		super();
		this.imageUrl = imageUrl;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	@Override
	public String toString() {
		return "Image [id=" + id + ", imageUrl=" + imageUrl + ", createDate=" + createDate + ", deleteDate="
				+ deleteDate + "]";
	}
}
