package ParallelProject.FilmManagementSystem.DAO;

import java.util.List;

import ParallelProject.FilmManagementSystem.Actor;
import ParallelProject.FilmManagementSystem.Album;
import ParallelProject.FilmManagementSystem.Film;
import ParallelProject.FilmManagementSystem.Image;

public interface ActorRepoDAO {
	boolean addActor(Actor actor);
	boolean modifyActor(Actor actor);
	boolean deleteActor(Actor actor);
	List<Actor> searchActorByFirstName(String firstNmae);
	List<Actor> searchActorByFilm(String film);
	List<Actor> searchActorByLastName(String lastName);
	List<Actor> fetchAllActors();
	List<Album> fetchAllAlbums();
	List<Image> fetchAllImages();
	List<Film> fetchAllFilms();
	Album searchAlbum(String albumName);
	List<Film> searFilmByName(List<Film> filmsArray);
}
