package ParallelProject.FilmManagementSystem.DAO;

import java.util.Date;
import java.util.List;

import ParallelProject.FilmManagementSystem.Actor;
import ParallelProject.FilmManagementSystem.Category;
import ParallelProject.FilmManagementSystem.Film;
import ParallelProject.FilmManagementSystem.Image;

public interface FilmServiceDAO {
	String createFilm(String title,String descrption,Date releaseYear,String albumName,String language,String category,
			List<Actor> actors,Byte rating,short length);
	Boolean modifyFilm(Film film);
	Boolean deleteFilm(Film film);
	List<Film> searchFilmByFilmTitle(String filmName);
	List<Film> searchFilmByActor(String actorName);
	List<Film> searchFilmByReleaseDate(Date date);
	List<Film> searchFilmByRating(Byte rating);
	List<Film> searchFilmByCategory(String category);
	List<Film> searchFilmByLanguage(String language);
	String createCategory(String categoryName);
	String createImage(String imageURL);
	String createAlbum(String albumName,List<Image> images);
	List<Category> searchCategoryName(String categoryName);
}
