package ParallelProject.FilmManagementSystem.DAO;

import java.util.Date;
import java.util.List;

import ParallelProject.FilmManagementSystem.Album;
import ParallelProject.FilmManagementSystem.Category;
import ParallelProject.FilmManagementSystem.Film;
import ParallelProject.FilmManagementSystem.Image;

public interface FilmRepoDAO {
	Boolean addFilm(Film film);
	Boolean modifyFilm(Film film);
	Boolean deleteFilm(Film film);
	Boolean addCategory(Category category);
	Boolean addImage(Image image);
	Boolean addAlbum(Album album);
	List<Film> searchFilmByFilmTitle(String filmName);
	List<Film> searchFilmByActor(String actorName);
	List<Film> searchFilmByReleaseDate(Date date);
	List<Film> searchFilmByRating(Byte rating);
	List<Film> searchFilmByCategory(String category);
	List<Film> searchFilmByLanguage(String language);
	List<Category> fetchAllCategories();
	List<Category> fetchCategoryByName(String categoryName);
}
