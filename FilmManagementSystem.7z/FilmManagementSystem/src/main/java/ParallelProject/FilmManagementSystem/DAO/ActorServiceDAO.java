package ParallelProject.FilmManagementSystem.DAO;

import java.util.List;

import ParallelProject.FilmManagementSystem.Actor;
import ParallelProject.FilmManagementSystem.Film;

public interface ActorServiceDAO {
	String createActor(String firstName, String lastName, String gender, String albumName, List<Film> films);
	Boolean modifyActor(Actor actor);
	Boolean deleteActor(Actor actor);
	List<Actor> searchActorByFirstName(String firstNmae);
	List<Actor> searchActorByFilm(String film);
	List<Actor> searchActorByLastName(String lastName);
}
