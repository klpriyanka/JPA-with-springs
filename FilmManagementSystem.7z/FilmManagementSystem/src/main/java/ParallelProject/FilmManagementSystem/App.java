package ParallelProject.FilmManagementSystem;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class App 
{
    public static void main( String[] args )
    {
    	EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		
		System.out.println("******************************************");
		em.getTransaction().begin();
		
		Category category=new Category();
		category.setCategoryName("horror");
		category.setCreateDate(new Date());
		
		em.persist(category);
		
		Category category1=new Category();
		category1.setCategoryName("comedy");
		category1.setCreateDate(new Date());
		
		em.persist(category1);
		
		TypedQuery<Category> query4=em.createQuery("select c from  Category c",Category.class);
		
		Category category2=new Category();
		category2.setCategoryName("horror");
		category2.setCreateDate(new Date());
		int flag=0;
		for(int i=0; i<query4.getResultList().size();i++){
			//System.out.println(query4.getResultList().get(i).getCategoryName()+"***************************");
			if(query4.getResultList().get(i).getCategoryName().equals(category2.getCategoryName()))
				flag++;		
		}
		if(flag == 0)
			em.persist(category2);
		Image img=new Image();
		img.setImageUrl("D:\\Users\\kalpriya\\Desktop\\google-small.png");
		img.setCreateDate(new Date());
		em.persist(img);
		Image img1=new Image();
		img1.setImageUrl("D:\\Users\\kalpriya\\Desktop\\signin-button.png");
		img1.setCreateDate(new Date());
		em.persist(img1);
	
		Image img2=new Image();
		img2.setImageUrl("D:\\Users\\kalpriya\\Desktop\\images.png");
		img2.setCreateDate(new Date());
		em.persist(img1);
		
		
		Album album=new Album();
		album.setAlbumName("myAlbum");
		album.setCreateDate(new Date());
		TypedQuery<Image> query=em.createQuery("select i from  Image i",Image.class);
		album.setImages(query.getResultList());
		em.persist(album);
		
		Actor actor=new Actor();
		actor.setFirstName("Nikitha1");
		actor.setLastName("Shiva1");
		TypedQuery<Album> query1=em.createQuery("select a from Album a where a.albumName = 'myAlbum'",Album.class);
		System.out.println(query1.getFirstResult()+"************************************");
		actor.setAlbum(query1.getSingleResult()); 
		actor.setCreateDate(new Date());
		actor.setGender("female");
		TypedQuery<Film> query2=em.createQuery("select f from  Film f",Film.class);
		actor.setFilm(query2.getResultList());
		em.persist(actor);
		
		
		Film film=new Film();
		TypedQuery<Actor> query3=em.createQuery("select a from Actor a",Actor.class);
		film.setActors(query3.getResultList());
		
		TypedQuery<Album> query5=em.createQuery("select a from Album a where a.albumName = 'myAlbum'",Album.class);
		film.setAlbum(query5.getSingleResult());
		
		TypedQuery<Category> query8=em.createQuery("select c from  Category c",Category.class);
		film.setCategory(query8.getResultList());
		film.setCreateDate(new Date());
		film.setDescription("description of film");
		film.setLanguage("telugu");
		film.setTitle("myFilm");
		film.setRating((byte) 4);
		film.setReleaseYear(new Date());
		em.persist(film);
		
		em.getTransaction( ).commit( );
		
		
		em.close();
		emf.close();
        
    }
}
