package ParallelProject.FilmManagementSystem;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Album {
	@Id @GeneratedValue(strategy=GenerationType.TABLE) 
	private int id;
	private String albumName;
	@OneToMany
	private List<Image> images;
	@Temporal(TemporalType.DATE)
	private Date createDate;
	@Temporal(TemporalType.DATE)
	private Date deleteDate;
	public Album() {
		// TODO Auto-generated constructor stub
	}
	public Album(String albumName, List<Image> images, Date createDate, Date deleteDate) {
		super();		
		this.albumName = albumName;
		this.images = images;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}	
	public String getAlbumName() {
		return albumName;
	}
	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	public List<Image> getImages() {
		return images;
	}
	public void setImages(List<Image> images) {
		this.images = images;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	@Override
	public String toString() {
		return "Album [id=" + id + ", albumName=" + albumName + ", images=" + images + ", createDate=" + createDate
				+ ", deleteDate=" + deleteDate + "]";
	}
}
